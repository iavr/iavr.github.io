The supplementary material for paper #1016 includes:

1. document p1016_supp.pdf: a report including additional information on the paper, mainly algorithms and proofs of all theoretical results

2. document mfd_documentation.pdf: basic documentation and examples of our MFD detector executable

3. archive mfd_software.zip: MFD detector executable