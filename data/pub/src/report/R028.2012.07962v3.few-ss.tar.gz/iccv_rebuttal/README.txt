
To create a sample ICCV rebuttal pdf, copy the contents of this directory somewhere, and type

 latex egrebuttal

or 

 pdflatex egrebuttal


Make sure to replace the paper title and paper ID in the appropriate places in the tex file.

Note that in some environments, it may be necessary to run bibtex explicitly (bibtex egrebuttal).
