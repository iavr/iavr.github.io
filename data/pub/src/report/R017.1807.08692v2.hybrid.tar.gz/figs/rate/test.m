load oxf5k_eigvals.mat
D = sort(D, 'descend');
alpha = 0.99;
R = 300;
s = 5;
rate = @(k,n) 2 * ((sqrt(k) - 1) ./ (sqrt(k) + 1)).^n;
kappa = (1 - alpha * D(end)) ./ (1 - alpha * D(1:s:R));

figure(1), clf
semilogy(rate(kappa, 1)), hold on
I = 20; for i = 2:I, semilogy(rate(kappa, i)), end

L = cell(I,1);
for i = 1:I, L{i} = sprintf('iter=%d', i); end
legend(L);

x = 1:s:R;
y = 1:I;
[X,Y] = meshgrid(x,y);
Z = rate(kappa, y)';

figure(2), clf
[c,h] = contour(X, Y, Z, 8);
clabel(c, h);

% eigs=[(1:length(D))' D];
% cont = c';
% save('eig.txt', 'eigs', '-ascii')
% save('contour.txt', 'cont', '-ascii')
