# visapp_gradient
